Tabelle der Komplexitäten
ein Rechenschritt: 1 Nanosekunde (10^(-9)sec)
k       ldn         n     n*ldn          n^2          n^3                 2^n
1      1 ns      2 ns      2 ns         4 ns         8 ns                4 ns
2      2 ns      4 ns      8 ns        16 ns        64 ns               16 ns
3      3 ns      8 ns     24 ns        64 ns       512 ns              256 ns
4      4 ns     16 ns     64 ns       256 ns         4 µs               66 µs
5      5 ns     32 ns    160 ns         1 µs        33 µs                 4 s
6      6 ns     64 ns    384 ns          4 µ       262 µs           585 Years
7      7 ns    128 ns    896 ns        16 µs         2 ms   1*10^20 Centuries
8      8 ns    256 ns      2 µs        66 µs        17 ms   4*10^58 Centuries
9      9 ns    512 ns      5 µs       262 µs       134 ms  4*10^135 Centuries

Insertion sort 			n^2
Selection Sort 			n^2 
Buble Sort 				n^2
Mergesort 				log2(n)
Quicksort				log2(n)
binäre Suche			log2(n)
lineare Suche			n
schnelles Potenzieren 	log2(n)
Quersumme Dezimalzahl	n
Fibonacci rekusiv		2^n
iterativ				(O)n