import java.lang.reflect.Array;
import java.util.Arrays;

/*********************************************************
 1.
 von links groeßeres
 von rechts kleineres
 a = {5, 3, 4, 8, 7, 1, 2} -->2
 a ={1, 3, 4, 8, 7, 5, 2}
 a={1, 2, 4, 8, 7, 5, 3} --> 2 Steht am richtigen Platz, links davon alles keliner und rechts alles größer.
 a={1, 2| 4, 8, 7, 5, 3 }
 a={1, 2, 3, 8, 7, 5, 4} --> 3 steht am richtigen Platz
 a={1, 2, 3| 8, 7, 5, 4}
 a={1, 2, 3, 4, 7, 5, 8} --> 4 steht am richtigen Platz
 a={1, 2, 3, 4| 7, 5, 8}
 a={1, 2, 3, 4|8, 5, 7}
 a={1, 2, 3, 4|5, 8, 7}
 a={1, 2, 3, 4, 5, 7, 8}
 2. 1,38nlog2n = Quicksort
    n^2/2 = bubble sort
    n^2/2 = Selection Sort
    n^2/4 = Insertion Sort
    also angenommen n = 10, dann ist Quicksort am 2. effizientesten nach Insertion Sort
 Worst case entweder wenn:
                    das array schon geordnet ist (angenommen dieser fall ist nicht ausgeschlossen)
                    das array ist falsch herum geordnet
                    alle elemente die selben sind


**********************************************************/
public class QuickSort {
    public static <T extends Comparable<T>> void quickSort(T[] a) {
        _quicksort (a ,0 , a . length -1) ;
        System.out.println(Arrays.deepToString(a));

    }

    public static <T extends Comparable<T>> void  _quicksort(T[] a, int l, int r  ){
        if(r>l){
            int m = partition(a, l, r);
            _quicksort(a, l, m-1);
            _quicksort(a, m+1, r);
        }

    }

    static <T extends Comparable<T>> int partition (T[] a , int l ,int r){
        assert (l<=r);
        T p= a[r];
        T t=p;
        int i= l-1;
        int j=r;
        do {
            do {

                ++i;
            } while (a[i].compareTo(p) == -1);
            do {
                --j;
            } while (j > l && a[j].compareTo(p) == 1);
            t= a[i];
            a[i]=a[j];
            a[j]=t;
        }while(i<j);

        a[j] = a[i];
        a[i] = a[r];
        a[r] = t;


        return i;

    }

    public static void main(String[] args) {
        Clock a[]= new Clock[5];
        for (int i=0; i<a.length; i++){
            int randh= (int) (Math.random()*24);
            int randm= (int) (Math.random()*59);
            Clock rando= new Clock(randh, randm);
            a[i]=rando;
        }
        quickSort(a);
    }
}